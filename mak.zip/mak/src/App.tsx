import UserTile from "./components/UserTile";

function App() {
  return <UserTile />;
}

export default App;
